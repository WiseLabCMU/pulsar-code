var driver__MMA8652_8c =
[
    [ "MMA8652_ACCEL_FIFO_SIZE", "driver__MMA8652_8c.html#aec02b963dc94a1a6ef8a0fb03abdf295", null ],
    [ "MMA8652_COUNTSPERG", "driver__MMA8652_8c.html#a5102c19894b1a3264dde9c0687402978", null ]
];
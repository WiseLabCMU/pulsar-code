var driver__MAG3110_8c =
[
    [ "MAG3110_COUNTSPERUT", "driver__MAG3110_8c.html#adbf5c8a408890310814f5c4164bea016", null ],
    [ "MAG3110_Idle", "driver__MAG3110_8c.html#a708eb59e48e61ea04dce5a3d07884933", null ],
    [ "MAG3110_Init", "driver__MAG3110_8c.html#ab25e9152fa726f2bcd148b9a0dbde157", null ],
    [ "MAG3110_Read", "driver__MAG3110_8c.html#a814ed032bb557dfa5bd0349d06b92d26", null ],
    [ "MAG3110_DATA_READ", "driver__MAG3110_8c.html#a7b0b70dd50ccb2b97cc0f746e8c3d6c6", null ],
    [ "MAG3110_DR_STATUS_READ", "driver__MAG3110_8c.html#ac2afbef6f9446f2dcfa089df3adb4a7f", null ],
    [ "MAG3110_IDLE", "driver__MAG3110_8c.html#a1f3a34c1322fe026ab8bdabe1c45105e", null ],
    [ "MAG3110_Initialization", "driver__MAG3110_8c.html#a169d2185b7c090d79deeb3e16b41dab9", null ],
    [ "MAG3110_WHO_AM_I_READ", "driver__MAG3110_8c.html#a2506ebf17d5e09dda16d65198df08f0c", null ]
];
var approximations_8h =
[
    [ "facos_deg", "approximations_8h.html#a084fe0ff189767dca40fbe330d7394f0", null ],
    [ "fasin_deg", "approximations_8h.html#a956336cb9e7270c6cfbf667b1075c063", null ],
    [ "fatan2_deg", "approximations_8h.html#aebfdfbd2df0fe4472f9861b0738bb410", null ],
    [ "fatan_15deg", "approximations_8h.html#aab17a1fee362e4247f1636fb8fa984a3", null ],
    [ "fatan_deg", "approximations_8h.html#a09d50b3d2c3d4d24e447a9b960eb5267", null ]
];
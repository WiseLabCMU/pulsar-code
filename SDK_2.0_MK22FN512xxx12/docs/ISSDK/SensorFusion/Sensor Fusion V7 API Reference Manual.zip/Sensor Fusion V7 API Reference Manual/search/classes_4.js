var searchData=
[
  ['magbuffer',['MagBuffer',['../structMagBuffer.html',1,'']]],
  ['magcalibration',['MagCalibration',['../structMagCalibration.html',1,'']]],
  ['magsensor',['MagSensor',['../structMagSensor.html',1,'']]]
];

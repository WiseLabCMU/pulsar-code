var searchData=
[
  ['zeroarray',['zeroArray',['../sensor__fusion_8c.html#ac57932c39d665755aeee1e62fac763e3',1,'zeroArray(StatusSubsystem *pStatus, void *data, uint16_t size, uint16_t numElements, uint8_t check):&#160;sensor_fusion.c'],['../sensor__fusion_8h.html#a017fe7907e982f06eb66a446d055aaad',1,'zeroArray(struct StatusSubsystem *pStatus, void *data, uint16_t size, uint16_t numElements, uint8_t check):&#160;sensor_fusion.c']]]
];

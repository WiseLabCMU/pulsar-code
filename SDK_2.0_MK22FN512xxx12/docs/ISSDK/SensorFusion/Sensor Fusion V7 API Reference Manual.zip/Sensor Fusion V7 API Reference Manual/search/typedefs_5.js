var searchData=
[
  ['initializefusionengine_5ft',['initializeFusionEngine_t',['../sensor__fusion_8h.html#a59a47808575ade0f1719c1b9e9f0e85c',1,'sensor_fusion.h']]],
  ['initializesensor_5ft',['initializeSensor_t',['../sensor__fusion_8h.html#a94a511080fe3acc46bcee1a85f25432c',1,'sensor_fusion.h']]],
  ['installsensor_5ft',['installSensor_t',['../sensor__fusion_8h.html#a10eb47ea1a89ff0d7547235930d43271',1,'sensor_fusion.h']]],
  ['int16',['int16',['../sensor__fusion_8h.html#aa0d0fdc87fd135ef2bedb030901cdb9c',1,'sensor_fusion.h']]],
  ['int32',['int32',['../sensor__fusion_8h.html#ab7903878916593daecbeb95b98115ab0',1,'sensor_fusion.h']]],
  ['int8',['int8',['../sensor__fusion_8h.html#aa79c2d3de4fcd200458c406f40b2ae64',1,'sensor_fusion.h']]]
];

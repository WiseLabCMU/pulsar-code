var searchData=
[
  ['data_20structures_20from_20a_20high_20level',['Data Structures From a High Level',['../data_structures.html',1,'']]]
];

var searchData=
[
  ['smallmodulus',['SMALLMODULUS',['../orientation_8c.html#a75fd3bc70409015ca43f604bb0ba3c4c',1,'orientation.c']]],
  ['smallq0',['SMALLQ0',['../orientation_8c.html#a66564e58123257e31716bc9cfdc0754b',1,'orientation.c']]],
  ['spi_5faddr',['SPI_ADDR',['../sensor__fusion_8h.html#aedb0274e7d55732f16fd67bfec361d83',1,'sensor_fusion.h']]],
  ['sqrt15over4',['SQRT15OVER4',['../sensor__fusion_8h.html#a1483f9fe4e0329bd33b20b12af4df0d1',1,'sensor_fusion.h']]],
  ['success',['SUCCESS',['../driver__KSDK__NVM_8c.html#aa90cac659d18e8ef6294c7ae337f6b58',1,'driver_KSDK_NVM.c']]],
  ['syst_5fcsr',['SYST_CSR',['../driver__systick_8c.html#ab26b3fc75982181f81b185b206e897f6',1,'driver_systick.c']]],
  ['syst_5fcvr',['SYST_CVR',['../driver__systick_8c.html#ae3dc4d2dbfdf38c593a5581415fecfed',1,'driver_systick.c']]],
  ['syst_5frvr',['SYST_RVR',['../driver__systick_8c.html#a4e8efcc1f2b551dbf3cb0aae1231e380',1,'driver_systick.c']]]
];

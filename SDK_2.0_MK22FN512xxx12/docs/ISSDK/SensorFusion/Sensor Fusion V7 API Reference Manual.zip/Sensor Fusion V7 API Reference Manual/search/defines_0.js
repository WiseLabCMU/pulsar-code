var searchData=
[
  ['accel_5fcal_5faveraging_5fsecs',['ACCEL_CAL_AVERAGING_SECS',['../precisionAccelerometer_8h.html#a2b9b9bab44fce8ba83b6da0bc9edb21c',1,'precisionAccelerometer.h']]],
  ['accel_5ffifo_5fsize',['ACCEL_FIFO_SIZE',['../standard__build_8h.html#a4c185218ef46ba2991d62b28e1620539',1,'standard_build.h']]],
  ['accel_5fodr_5fhz',['ACCEL_ODR_HZ',['../standard__build_8h.html#a488f0b36828838716f4cae7a03dbf990',1,'standard_build.h']]],
  ['android',['ANDROID',['../standard__build_8h.html#a84b6d92b7538d9eb6d3cc527c0450558',1,'standard_build.h']]]
];

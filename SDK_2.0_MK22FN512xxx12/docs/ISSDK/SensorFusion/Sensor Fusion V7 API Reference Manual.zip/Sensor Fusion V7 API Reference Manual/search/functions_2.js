var searchData=
[
  ['clearfifos',['clearFIFOs',['../sensor__fusion_8c.html#a9af8710b3e87acd2a33e7988b2d75b6c',1,'clearFIFOs(SensorFusionGlobals *sfg):&#160;sensor_fusion.c'],['../sensor__fusion_8h.html#a9af8710b3e87acd2a33e7988b2d75b6c',1,'clearFIFOs(SensorFusionGlobals *sfg):&#160;sensor_fusion.c']]],
  ['conditionsample',['conditionSample',['../sensor__fusion_8c.html#a2686eeb8ae44e588362478db1f757a0e',1,'conditionSample(int16_t sample[3]):&#160;sensor_fusion.c'],['../sensor__fusion_8h.html#a2686eeb8ae44e588362478db1f757a0e',1,'conditionSample(int16_t sample[3]):&#160;sensor_fusion.c']]],
  ['conditionsensorreadings',['conditionSensorReadings',['../sensor__fusion_8c.html#aef2b1f23f820d2b513bc827f8baffd0d',1,'conditionSensorReadings(SensorFusionGlobals *sfg):&#160;sensor_fusion.c'],['../sensor__fusion_8h.html#aef2b1f23f820d2b513bc827f8baffd0d',1,'conditionSensorReadings(SensorFusionGlobals *sfg):&#160;sensor_fusion.c']]],
  ['createandsendpackets',['CreateAndSendPackets',['../control_8h.html#adbb4129e795ca534e4bb1649bb81b559',1,'CreateAndSendPackets(SensorFusionGlobals *sfg, uint8_t *sUARTOutputBuffer):&#160;output_stream.c'],['../output__stream_8c.html#adbb4129e795ca534e4bb1649bb81b559',1,'CreateAndSendPackets(SensorFusionGlobals *sfg, uint8_t *sUARTOutputBuffer):&#160;output_stream.c']]]
];

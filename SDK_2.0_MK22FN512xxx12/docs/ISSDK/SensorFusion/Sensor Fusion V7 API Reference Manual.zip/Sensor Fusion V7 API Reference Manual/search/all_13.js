var searchData=
[
  ['vapplicationidlehook',['vApplicationIdleHook',['../main__freertos__agm02__power__cycling_8c.html#a97fd430f36f8b065226e2bff9bad1de5',1,'main_freertos_agm02_power_cycling.c']]],
  ['vapplicationtickhook',['vApplicationTickHook',['../main__freertos__agm02__power__cycling_8c.html#a9ca051aa77e17583aa5a85d5de5c199a',1,'main_freertos_agm02_power_cycling.c']]]
];

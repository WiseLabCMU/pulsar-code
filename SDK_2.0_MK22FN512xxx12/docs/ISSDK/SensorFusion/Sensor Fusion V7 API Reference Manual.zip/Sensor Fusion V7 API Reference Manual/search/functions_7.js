var searchData=
[
  ['mag3110_5fidle',['MAG3110_Idle',['../driver__MAG3110_8c.html#a708eb59e48e61ea04dce5a3d07884933',1,'MAG3110_Idle(PhysicalSensor *sensor, SensorFusionGlobals *sfg):&#160;driver_MAG3110.c'],['../drivers_8h.html#a708eb59e48e61ea04dce5a3d07884933',1,'MAG3110_Idle(PhysicalSensor *sensor, SensorFusionGlobals *sfg):&#160;driver_MAG3110.c']]],
  ['mag3110_5finit',['MAG3110_Init',['../driver__MAG3110_8c.html#ab25e9152fa726f2bcd148b9a0dbde157',1,'MAG3110_Init(PhysicalSensor *sensor, SensorFusionGlobals *sfg):&#160;driver_MAG3110.c'],['../drivers_8h.html#ab25e9152fa726f2bcd148b9a0dbde157',1,'MAG3110_Init(PhysicalSensor *sensor, SensorFusionGlobals *sfg):&#160;driver_MAG3110.c']]],
  ['mag3110_5fread',['MAG3110_Read',['../driver__MAG3110_8c.html#a814ed032bb557dfa5bd0349d06b92d26',1,'MAG3110_Read(PhysicalSensor *sensor, SensorFusionGlobals *sfg):&#160;driver_MAG3110.c'],['../drivers_8h.html#a814ed032bb557dfa5bd0349d06b92d26',1,'MAG3110_Read(PhysicalSensor *sensor, SensorFusionGlobals *sfg):&#160;driver_MAG3110.c']]],
  ['main',['main',['../main__agm01__freertos__two__tasks_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main_agm01_freertos_two_tasks.c'],['../main__baremetal_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main_baremetal.c'],['../main__freertos__agm02_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main_freertos_agm02.c'],['../main__freertos__agm02__power__cycling_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main_freertos_agm02_power_cycling.c'],['../main__freertos__single__task_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main_freertos_single_task.c'],['../main__freertos__two__tasks_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main_freertos_two_tasks.c']]],
  ['mma8451_5fidle',['MMA8451_Idle',['../drivers_8h.html#a222c12af70c00e7e6c67f665180b0645',1,'drivers.h']]],
  ['mma8451_5finit',['MMA8451_Init',['../drivers_8h.html#a23a0c55b69ebc03426cc9dd26d7560de',1,'drivers.h']]],
  ['mma8451_5fread',['MMA8451_Read',['../drivers_8h.html#a548e731f3f5eacb312e663f537338d97',1,'drivers.h']]],
  ['mma8652_5fidle',['MMA8652_Idle',['../drivers_8h.html#a0dca683dd2636b2638f42bb93ab71ea4',1,'drivers.h']]],
  ['mma8652_5finit',['MMA8652_Init',['../drivers_8h.html#a17ba4ee17faecde2b6752868995c768b',1,'drivers.h']]],
  ['mma8652_5fread',['MMA8652_Read',['../drivers_8h.html#af305ac46dced67ca87098d066b777ab2',1,'drivers.h']]],
  ['motioncheck',['motionCheck',['../main__freertos__agm02__power__cycling_8c.html#a9bc3ff19e01b5212420dbe5bd004b40a',1,'motionCheck(float sample[3], float baseline[3], float tolerance, uint32_t winLength, uint32_t *count):&#160;motionCheck.c'],['../motionCheck_8c.html#a9bc3ff19e01b5212420dbe5bd004b40a',1,'motionCheck(float sample[3], float baseline[3], float tolerance, uint32_t winLength, uint32_t *count):&#160;motionCheck.c']]],
  ['mpl3115_5fidle',['MPL3115_Idle',['../drivers_8h.html#a379dd1bcbaab047712b8cebb922fbd51',1,'drivers.h']]],
  ['mpl3115_5finit',['MPL3115_Init',['../drivers_8h.html#a3e1e95cf3c04b11bd0aea5368269e4e3',1,'drivers.h']]],
  ['mpl3115_5fread',['MPL3115_Read',['../drivers_8h.html#a6c7ac9be0b5038427b17e268320018ac',1,'drivers.h']]],
  ['myi2c_5fcallback',['myI2C_callback',['../main__freertos__single__task_8c.html#a74c29746b187d40824203a7cbfa27b6e',1,'main_freertos_single_task.c']]],
  ['myuart_5fwritebyte',['myUART_WriteByte',['../control_8c.html#a9f548c7fc2a3dce2f1c2b0c044dbd2c8',1,'control.c']]]
];

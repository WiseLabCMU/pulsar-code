var searchData=
[
  ['initializecontrolport',['initializeControlPort',['../control_8c.html#a67029acf1be9712c5d30c625132ad958',1,'initializeControlPort(ControlSubsystem *pComm):&#160;control.c'],['../control_8h.html#a67029acf1be9712c5d30c625132ad958',1,'initializeControlPort(ControlSubsystem *pComm):&#160;control.c']]],
  ['initializefusionengine',['initializeFusionEngine',['../sensor__fusion_8c.html#ab088da7731ffdf25710a364a7f88b224',1,'sensor_fusion.c']]],
  ['initializesensors',['initializeSensors',['../sensor__fusion_8c.html#ae748e1330b5a94783c6d4ea2ad9e4f28',1,'sensor_fusion.c']]],
  ['initializestatussubsystem',['initializeStatusSubsystem',['../status_8c.html#a01619741119cf3432f8cfff23334c793',1,'initializeStatusSubsystem(StatusSubsystem *pStatus):&#160;status.c'],['../status_8h.html#a01619741119cf3432f8cfff23334c793',1,'initializeStatusSubsystem(StatusSubsystem *pStatus):&#160;status.c']]],
  ['initsensorfusionglobals',['initSensorFusionGlobals',['../sensor__fusion_8c.html#a43b44018042fabb5179c2e62277cc942',1,'initSensorFusionGlobals(SensorFusionGlobals *sfg, StatusSubsystem *pStatusSubsystem, ControlSubsystem *pControlSubsystem):&#160;sensor_fusion.c'],['../sensor__fusion_8h.html#a367d92b99365a8143700b76439915d65',1,'initSensorFusionGlobals(SensorFusionGlobals *sfg, struct StatusSubsystem *pStatusSubsystem, struct ControlSubsystem *pControlSubsystem):&#160;sensor_fusion.c']]],
  ['installsensor',['installSensor',['../sensor__fusion_8c.html#a45ee1600720deae228f488e6246a747b',1,'sensor_fusion.c']]],
  ['iupdatemagbuffer',['iUpdateMagBuffer',['../magnetic_8c.html#a3b07f7334d06c86a3e18732a5106a951',1,'iUpdateMagBuffer(MagBuffer *pthisMagBuffer, MagSensor *pthisMag, int32 loopcounter):&#160;magnetic.c'],['../magnetic_8h.html#ad566902c616f5bca1d71f33e8fbad7b8',1,'iUpdateMagBuffer(struct MagBuffer *pthisMagBuffer, struct MagSensor *pthisMag, int32_t loopcounter):&#160;magnetic.c']]]
];

var searchData=
[
  ['qaeqaxb',['qAeqAxB',['../orientation_8c.html#a22a32becfcb162db012f41ff4f3bc942',1,'qAeqAxB(Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c'],['../orientation_8h.html#a22a32becfcb162db012f41ff4f3bc942',1,'qAeqAxB(Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c']]],
  ['qaeqbxc',['qAeqBxC',['../orientation_8c.html#a12448c36b93d8f3375ce000ef4527b4a',1,'qAeqBxC(Quaternion *pqA, const Quaternion *pqB, const Quaternion *pqC):&#160;orientation.c'],['../orientation_8h.html#a12448c36b93d8f3375ce000ef4527b4a',1,'qAeqBxC(Quaternion *pqA, const Quaternion *pqB, const Quaternion *pqC):&#160;orientation.c']]],
  ['qconjgaxb',['qconjgAxB',['../orientation_8c.html#adb2ea2734ac13ca77b3218d761fe45e0',1,'qconjgAxB(const Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c'],['../orientation_8h.html#adb2ea2734ac13ca77b3218d761fe45e0',1,'qconjgAxB(const Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c']]],
  ['queuestatus',['queueStatus',['../sensor__fusion_8c.html#ae96e36747e6a1aabbec1381f15132ec6',1,'sensor_fusion.c']]]
];

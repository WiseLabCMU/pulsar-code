var searchData=
[
  ['api_2emd',['api.md',['../api_8md.html',1,'']]],
  ['approximations_2ec',['approximations.c',['../approximations_8c.html',1,'']]],
  ['approximations_2eh',['approximations.h',['../approximations_8h.html',1,'']]],
  ['architecture_2emd',['architecture.md',['../architecture_8md.html',1,'']]]
];

var searchData=
[
  ['saveaccelcalibrationtonvm',['SaveAccelCalibrationToNVM',['../calibration__storage_8c.html#a6cbf0fc4417e3a411a9685e2a92f1816',1,'SaveAccelCalibrationToNVM(SensorFusionGlobals *sfg):&#160;calibration_storage.c'],['../calibration__storage_8h.html#a6cbf0fc4417e3a411a9685e2a92f1816',1,'SaveAccelCalibrationToNVM(SensorFusionGlobals *sfg):&#160;calibration_storage.c']]],
  ['savegyrocalibrationtonvm',['SaveGyroCalibrationToNVM',['../calibration__storage_8c.html#aa5684d700f135264e542f33071ed6a45',1,'SaveGyroCalibrationToNVM(SensorFusionGlobals *sfg):&#160;calibration_storage.c'],['../calibration__storage_8h.html#aa5684d700f135264e542f33071ed6a45',1,'SaveGyroCalibrationToNVM(SensorFusionGlobals *sfg):&#160;calibration_storage.c']]],
  ['savemagcalibrationtonvm',['SaveMagCalibrationToNVM',['../calibration__storage_8c.html#ad08799ac63701e755fe2414b32f69b50',1,'SaveMagCalibrationToNVM(SensorFusionGlobals *sfg):&#160;calibration_storage.c'],['../calibration__storage_8h.html#ad08799ac63701e755fe2414b32f69b50',1,'SaveMagCalibrationToNVM(SensorFusionGlobals *sfg):&#160;calibration_storage.c']]],
  ['sbufappenditem',['sBufAppendItem',['../control_8h.html#a7ad6e53b35d6fc860a1299ceff40a299',1,'sBufAppendItem(uint8_t *pDest, uint16_t *pIndex, uint8_t *pSource, uint16_t iBytesToCopy):&#160;output_stream.c'],['../output__stream_8c.html#a7ad6e53b35d6fc860a1299ceff40a299',1,'sBufAppendItem(uint8_t *pDest, uint16_t *pIndex, uint8_t *pSource, uint16_t iBytesToCopy):&#160;output_stream.c']]],
  ['sbufappendzeros',['sBufAppendZeros',['../output__stream_8c.html#a93db92e775dee51c4dbf2dca2aed05b3',1,'output_stream.c']]],
  ['setstatus',['setStatus',['../sensor__fusion_8c.html#a741fd2193cc58c09b692d1ae2b7a81e8',1,'sensor_fusion.c']]],
  ['ssqueuestatus',['ssQueueStatus',['../status_8c.html#a8b18fb2d1aa207d82a91b964e618fc6f',1,'status.c']]],
  ['sssetleds',['ssSetLeds',['../status_8c.html#a9e4966ab161bb28de7d5f71fc48ed212',1,'status.c']]],
  ['sssetstatus',['ssSetStatus',['../status_8c.html#aa1eec664ba18958c8e54d696402232b9',1,'status.c']]],
  ['sssetstatusnow',['ssSetStatusNow',['../status_8c.html#a0c95bafe270ab48a3f4397bff655bad8',1,'status.c']]],
  ['sstest',['ssTest',['../status_8c.html#a965d11d38c1ccddb703fe6e29d087d8d',1,'status.c']]],
  ['ssupdatestatus',['ssUpdateStatus',['../status_8c.html#a163c3ee102397bef342e6e3e56b78a69',1,'status.c']]]
];

var searchData=
[
  ['n',['N',['../status_8c.html#a0240ac851181b84ac374872dc5434ee4',1,'status.c']]],
  ['ned',['NED',['../standard__build_8h.html#a48ffbe9396ac9a07c43d7f1bcf36fbc6',1,'standard_build.h']]],
  ['niterations',['NITERATIONS',['../matrix_8c.html#a5131cff305ea278a05522d767972129d',1,'NITERATIONS():&#160;matrix.c'],['../matrix_8c.html#a5131cff305ea278a05522d767972129d',1,'NITERATIONS():&#160;matrix.c']]]
];

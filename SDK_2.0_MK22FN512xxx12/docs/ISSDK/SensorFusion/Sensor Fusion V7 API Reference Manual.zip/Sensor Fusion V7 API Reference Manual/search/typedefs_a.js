var searchData=
[
  ['sensorfusionglobals',['SensorFusionGlobals',['../sensor__fusion_8h.html#ae22cd912bc7ce5c370d4854c16c677a0',1,'sensor_fusion.h']]],
  ['setstatus_5ft',['setStatus_t',['../sensor__fusion_8h.html#a64251c40a481b020646d114af8d9d8d5',1,'sensor_fusion.h']]],
  ['sssetstatus_5ft',['ssSetStatus_t',['../sensor__fusion_8h.html#acb6d6b68739a879ec32aae295d2c13e1',1,'sensor_fusion.h']]],
  ['ssupdatestatus_5ft',['ssUpdateStatus_t',['../sensor__fusion_8h.html#a9d3651382e5d36ecf04286d8e24c664e',1,'sensor_fusion.h']]],
  ['statussubsystem',['StatusSubsystem',['../status_8h.html#a154241b9e52d082750eaf7b25cbb06c0',1,'status.h']]],
  ['streamdata_5ft',['streamData_t',['../control_8h.html#a067b4c2ce3a778c349b3f77936c68b2d',1,'control.h']]],
  ['sv_5f1dof_5fp_5fbasic',['SV_1DOF_P_BASIC',['../sensor__fusion_8h.html#abec65889f3805c921b0f87a3bbfe4a12',1,'sensor_fusion.h']]],
  ['sv_5f3dof_5fb_5fbasic',['SV_3DOF_B_BASIC',['../sensor__fusion_8h.html#a7af11fc9134e678b2c0ae379ebe0ad2b',1,'sensor_fusion.h']]],
  ['sv_5f3dof_5fg_5fbasic',['SV_3DOF_G_BASIC',['../sensor__fusion_8h.html#af07d272908d43dd47adc12d0cc1d3468',1,'sensor_fusion.h']]],
  ['sv_5f3dof_5fy_5fbasic',['SV_3DOF_Y_BASIC',['../sensor__fusion_8h.html#aae4fe8282ed3ea3bbdd23161c513b3e7',1,'sensor_fusion.h']]],
  ['sv_5f6dof_5fgb_5fbasic',['SV_6DOF_GB_BASIC',['../sensor__fusion_8h.html#ae62ff32ca1e5fdf43fb652223994ebb3',1,'sensor_fusion.h']]],
  ['sv_5f6dof_5fgy_5fkalman',['SV_6DOF_GY_KALMAN',['../sensor__fusion_8h.html#ae68c524d870f45f4728b6e494542cb5b',1,'sensor_fusion.h']]],
  ['sv_5f9dof_5fgby_5fkalman',['SV_9DOF_GBY_KALMAN',['../sensor__fusion_8h.html#a3126c3e6347fe05f8b07982957eed45a',1,'sensor_fusion.h']]],
  ['sv_5fcommon',['SV_COMMON',['../sensor__fusion_8h.html#a44ef0e24d171f38cff550f8a90a2e07d',1,'sensor_fusion.h']]],
  ['sv_5fptr',['SV_ptr',['../sensor__fusion_8h.html#aab2ba76be48461a53eba12bdb724cb2e',1,'sensor_fusion.h']]]
];

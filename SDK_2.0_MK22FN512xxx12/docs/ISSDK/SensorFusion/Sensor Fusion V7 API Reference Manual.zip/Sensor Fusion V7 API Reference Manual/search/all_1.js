var searchData=
[
  ['b',['B',['../status_8c.html#a111da81ae5883147168bbb8366377b10',1,'status.c']]],
  ['b0',['B0',['../sensor__fusion_8h.html#a8a03ef52aa4926d1d75cb647ac768622',1,'sensor_fusion.h']]],
  ['b1',['B1',['../sensor__fusion_8h.html#a7b21d6a6a4573b4997b1f04b01cd4efb',1,'sensor_fusion.h']]],
  ['b2',['B2',['../sensor__fusion_8h.html#a6945d50f798e1fde624d70c74457090e',1,'sensor_fusion.h']]],
  ['b3',['B3',['../sensor__fusion_8h.html#ae6ac0edb1e2c9c7672ab9488d8b65be9',1,'sensor_fusion.h']]],
  ['blueradios_5finit',['BlueRadios_Init',['../control_8c.html#a0022c0c45a3b736ffe21164001662b44',1,'BlueRadios_Init(void):&#160;control.c'],['../control_8h.html#a0022c0c45a3b736ffe21164001662b44',1,'BlueRadios_Init(void):&#160;control.c']]],
  ['board_5fencodings_2eh',['board_encodings.h',['../board__encodings_8h.html',1,'']]],
  ['bus_5fdriver',['bus_driver',['../structPhysicalSensor.html#aa7b3c47e2be4d604bc40157d590d09b2',1,'PhysicalSensor']]],
  ['byte',['byte',['../sensor__fusion_8h.html#a0c8186d9b9b7880309c27230bbb5e69d',1,'sensor_fusion.h']]]
];

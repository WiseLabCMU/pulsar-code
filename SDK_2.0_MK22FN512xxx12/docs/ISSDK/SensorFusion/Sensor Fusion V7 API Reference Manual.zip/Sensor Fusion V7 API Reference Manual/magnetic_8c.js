var magnetic_8c =
[
    [ "MATRIX_10_SIZE", "magnetic_8c.html#ae0f495621ec721f10da66b820efa650a", null ],
    [ "MATRIX_7_SIZE", "magnetic_8c.html#ab9e194e1043aac1f4ac6e693cc75ca31", null ],
    [ "fComputeMagCalibration10", "magnetic_8c.html#a0c8d40902766e8a8d295d97948552cd7", null ],
    [ "fComputeMagCalibration4", "magnetic_8c.html#afbf2fc5eb28136286990669004238ff9", null ],
    [ "fComputeMagCalibration7", "magnetic_8c.html#a5f40de5d6a5452756e4408a6eefbb9dc", null ],
    [ "fInitializeMagCalibration", "magnetic_8c.html#a793003e431e2705d081b5073144cb2c0", null ],
    [ "fInvertMagCal", "magnetic_8c.html#a0a0ba578c5de9f06431db84b2b8e3f9a", null ],
    [ "fRunMagCalibration", "magnetic_8c.html#a2c2da80362a7b97574c6b60972399b73", null ],
    [ "fUpdateMagCalibration10Slice", "magnetic_8c.html#a5798cb74fc7f5956db643d09a3750e09", null ],
    [ "fUpdateMagCalibration4Slice", "magnetic_8c.html#ab6f86b6d28bc71b2ce3afc7c374c462e", null ],
    [ "fUpdateMagCalibration7Slice", "magnetic_8c.html#aad08380c7f86edfe8480d6a7555172b8", null ],
    [ "iUpdateMagBuffer", "magnetic_8c.html#a3b07f7334d06c86a3e18732a5106a951", null ]
];
var driver__MMA845X_8c =
[
    [ "MMA8451_ACCEL_FIFO_SIZE", "driver__MMA845X_8c.html#a3298c7a34422a2de67f604940b8279e0", null ],
    [ "MMA845x_COUNTSPERG", "driver__MMA845X_8c.html#a66f87e76366d6088e7fda866ad86b0b6", null ]
];
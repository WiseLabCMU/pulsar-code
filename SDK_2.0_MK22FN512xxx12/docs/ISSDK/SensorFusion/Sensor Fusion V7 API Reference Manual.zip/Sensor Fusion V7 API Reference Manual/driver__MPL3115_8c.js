var driver__MPL3115_8c =
[
    [ "MPL3115_ACCEL_FIFO_SIZE", "driver__MPL3115_8c.html#a8ec1cf97f28f5d27ce8eb03c74a75f4f", null ],
    [ "MPL3115_CPERCOUNT", "driver__MPL3115_8c.html#aa225a895b25fe7cd9592cefba8e0ce54", null ],
    [ "MPL3115_MPERCOUNT", "driver__MPL3115_8c.html#a6ac40b0b9c9f9e7cf5de060f0fae3562", null ]
];
var driver__FXLS8952_8c =
[
    [ "FXLS8952_ACCEL_FIFO_SIZE", "driver__FXLS8952_8c.html#a5396302f349853253b5390288ef2e3a6", null ],
    [ "FXLS8952_COUNTSPERG", "driver__FXLS8952_8c.html#a31f854b8f26bf2bdb3c23645760f9903", null ]
];
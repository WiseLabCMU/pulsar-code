var approximations_8c =
[
    [ "PADE_A", "approximations_8c.html#adb080357bd17e75e99457e4784de58b5", null ],
    [ "PADE_B", "approximations_8c.html#aa333bd5cecf10cb50fc1be1d9ab859b7", null ],
    [ "PADE_C", "approximations_8c.html#a1fa3184d75c706cea6e8f26261630100", null ],
    [ "TAN15DEG", "approximations_8c.html#af3c8dd0138fad67491f72c8888b8476b", null ],
    [ "TAN30DEG", "approximations_8c.html#a95b284aae960aeb6640b0c7cbc583145", null ],
    [ "facos_deg", "approximations_8c.html#a084fe0ff189767dca40fbe330d7394f0", null ],
    [ "fasin_deg", "approximations_8c.html#a956336cb9e7270c6cfbf667b1075c063", null ],
    [ "fatan2_deg", "approximations_8c.html#aebfdfbd2df0fe4472f9861b0738bb410", null ],
    [ "fatan_15deg", "approximations_8c.html#aab17a1fee362e4247f1636fb8fa984a3", null ],
    [ "fatan_deg", "approximations_8c.html#a09d50b3d2c3d4d24e447a9b960eb5267", null ]
];
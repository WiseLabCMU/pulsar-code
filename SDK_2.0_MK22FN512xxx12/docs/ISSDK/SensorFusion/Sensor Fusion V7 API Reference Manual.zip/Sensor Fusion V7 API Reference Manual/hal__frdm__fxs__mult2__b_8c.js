var hal__frdm__fxs__mult2__b_8c =
[
    [ "ApplyAccelHAL", "hal__frdm__fxs__mult2__b_8c.html#a6bb19bade42d7adef32375e174de144d", null ],
    [ "ApplyGyroHAL", "hal__frdm__fxs__mult2__b_8c.html#a9b489a682e07db8c11a2121ede929e9e", null ],
    [ "ApplyMagHAL", "hal__frdm__fxs__mult2__b_8c.html#a61ed96ce5838a7f7952539b7d7d944dc", null ]
];